#include "deminwidget.h"
#include <QApplication>
#include <QTranslator>
using namespace std;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QTranslator translator;
       if(translator.load(QLocale::system(), "Traduire", "_", a.applicationDirPath(), ".qm")) {
           a.installTranslator(&translator);
       }
    DemineWidget d;
    d.show();

    return a.exec();
}
