#include "game.h"

Game::Game(int width, int height, int bombs)
    : gridWidth(width), gridHeight(height), bombCount(bombs), firstClick(true) {
    initialize();
}

void Game::initialize() {
    buttons.resize(gridWidth * gridHeight, nullptr);
    bombLocations.resize(gridWidth * gridHeight, false);

    for (int i = 0; i < gridWidth * gridHeight; ++i) {
        buttons[i] = new QPushButton();
    }

    placeBombs();
}


void Game::placeBombs() {
    if (bombCount > gridWidth * gridHeight) {
        throw std::invalid_argument("bombCount exceeds the grid size");
    }
    std::vector<int> positions(gridWidth * gridHeight);
    std::iota(positions.begin(), positions.end(), 0);

    static std::mt19937 rng(std::random_device{}());
    std::shuffle(positions.begin(), positions.end(), rng);

    for (int i = 0; i < bombCount; ++i) {
        bombLocations[positions[i]] = true;
    }
}


bool Game::isBomb(int index) const {
    return bombLocations[index];
}

int Game::countAdjacentBombs(int index) const {
    QVector<int> neighbors = getAdjacentIndices(index);
    return std::count_if(neighbors.begin(), neighbors.end(), [&](int i) { return bombLocations[i]; });
}

QVector<int> Game::getAdjacentIndices(int index) const {
    QVector<int> adjacentIndices;

    int row = index / gridWidth;  // Ligne actuelle
    int col = index % gridWidth;  // Colonne actuelle

    // Parcours des 8 directions possibles
    for (int i = row - 1; i <= row + 1; ++i) {
        for (int j = col - 1; j <= col + 1; ++j) {
            if (i >= 0 && i < gridHeight && j >= 0 && j < gridWidth) {
                if (!(i == row && j == col)) {  // Ignorer la case elle-même
                    int neighborIndex = i * gridWidth + j;
                    adjacentIndices.append(neighborIndex);
                }
            }
        }
    }
    return adjacentIndices;
}



std::vector<QPushButton*>& Game::getButtons() {
    return buttons;
}
const std::vector<bool>& Game::getBombLocations() const {
    return bombLocations;
}

int Game::getRemainingBombs() const {
    return bombCount;
}

void Game::setRemainingBombs(int bombs) {
    bombCount = bombs;
}


void Game::moveBomb(int index) {
    bombLocations[index] = false;
    int newIndex;
    do {
        newIndex = rand() % buttons.size();
    } while (bombLocations[newIndex] || newIndex == index);
    bombLocations[newIndex] = true;
}

void Game::revealAdjacentEmptyCells(int index, QSet<int> &visited) {
    // ici je verifie si la case a déjà été visitée pour éviter les boucles infinies
    if (visited.contains(index)) {
        return;
    }

    // marquage de  la case comme visitée
    visited.insert(index);

    // Obtenir les indices des cases adjacentes
    QVector<int> adjacentIndices = getAdjacentIndices(index);

    for (int adjIndex : adjacentIndices) {
        QPushButton *adjButton = buttons[adjIndex];
        QString adjState = adjButton->property("iconState").toString();

        // si la case est vide et encore cliquable
        if (adjState.isEmpty() && adjButton->isEnabled()) {
            adjButton->setStyleSheet("border: 1px solid lightgreen;"); // Bordure verte
            int adjBombCount = countAdjacentBombs(adjIndex);

            if (adjBombCount > 0) {
                adjButton->setText(QString::number(adjBombCount));
            } else {
                adjButton->setText(""); // Case vide
                revealAdjacentEmptyCells(adjIndex, visited); // Révéler les voisins
            }
            adjButton->setEnabled(false); // Désactiver la case après révélation
        }
    }
}

bool Game::checkVictory() const {
    for (size_t i = 0; i < buttons.size(); ++i) {
        if (!bombLocations[i] && buttons[i]->isEnabled()) {
            return false; // Il reste encore des cases non découvertes
        }
    }
    return true; // toutes les cases ont été découverte
}
