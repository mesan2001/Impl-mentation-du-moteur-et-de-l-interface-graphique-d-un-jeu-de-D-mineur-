<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>DemineWidget</name>
    <message>
        <location filename="deminwidget.cpp" line="83"/>
        <source>Quit</source>
        <oldsource>Quitter</oldsource>
        <translation type="unfinished">Quit</translation>
    </message>
    <message>
        <source>View scores</source>
        <oldsource>Voir les scores</oldsource>
        <translation type="obsolete">View scores</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="122"/>
        <source>Minesweeper game
Developed by Messan Joseph ANANI</source>
        <oldsource>Jeu de démineur
Développé par Messan Joseph ANANI</oldsource>
        <translation type="unfinished">Minesweeper game
Developed by Messan Joseph ANANI</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="136"/>
        <source>Scores</source>
        <translation type="unfinished">Scores</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="308"/>
        <source>Choose the level</source>
        <oldsource>Choisir le niveau</oldsource>
        <translation type="unfinished">Choose the level</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="18"/>
        <source>Minesweeper</source>
        <translation type="unfinished">Minesweeper</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="78"/>
        <source>Create a new game</source>
        <translation type="unfinished">Create a new game</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="88"/>
        <source>Leaderboard - Easy</source>
        <translation type="unfinished">Leaderboard - Easy</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="90"/>
        <source>Ctrl+E</source>
        <translation type="unfinished">Ctrl+E</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="93"/>
        <source>Leaderboard - Medium</source>
        <translation type="unfinished">Leaderboard - Medium</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="95"/>
        <source>Ctrl+M</source>
        <translation type="unfinished">Ctrl+M</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="98"/>
        <source>Leaderboard - Hard</source>
        <translation type="unfinished">Leaderboard - Hard</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="100"/>
        <source>Ctrl+H</source>
        <translation type="unfinished">Ctrl+H</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="103"/>
        <source>About Qt</source>
        <translation type="unfinished">About Qt</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="105"/>
        <source>Ctrl+A</source>
        <translation type="unfinished">Ctrl+A</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="108"/>
        <location filename="deminwidget.cpp" line="121"/>
        <source>About Minesweeper</source>
        <translation type="unfinished">About Minesweeper</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="110"/>
        <source>Ctrl+G</source>
        <translation type="unfinished">Ctrl+G</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="131"/>
        <source>File</source>
        <translation type="unfinished">File</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="142"/>
        <source>About</source>
        <translation type="unfinished">About</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="311"/>
        <source>Easy - 10x10 with 10 bombs</source>
        <translation type="unfinished">Easy - 10x10 with 10 bombs</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="312"/>
        <source>Medium - 16x16 with 16 bombs</source>
        <translation type="unfinished">Medium - 16x16 with 16 bombs</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="313"/>
        <source>Hard - 32x16 with 64 bombs</source>
        <translation type="unfinished">Hard - 32x16 with 64 bombs</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="323"/>
        <source>OK</source>
        <translation type="unfinished">OK</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="324"/>
        <source>Cancel</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="360"/>
        <source>Leaderboard %1

</source>
        <oldsource>Palmarès %1

</oldsource>
        <translation type="unfinished">Leaderboard %1

</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="367"/>
        <location filename="deminwidget.cpp" line="506"/>
        <source>Easy</source>
        <translation type="unfinished">Easy</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="372"/>
        <location filename="deminwidget.cpp" line="508"/>
        <source>Medium</source>
        <translation type="unfinished">Medium</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="377"/>
        <location filename="deminwidget.cpp" line="510"/>
        <source>Hard</source>
        <translation type="unfinished">Hard</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="457"/>
        <source>Game Over</source>
        <translation type="unfinished">Game Over</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="457"/>
        <source>Too bad! You triggered a bomb.
Game Over!</source>
        <translation type="unfinished">Too bad! You triggered a bomb.
Game Over!</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="483"/>
        <source>%1 min %2 sec</source>
        <translation type="unfinished">%1 min %2 sec</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="484"/>
        <source>%1 sec</source>
        <translation type="unfinished">%1 sec</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="488"/>
        <source>Congratulations!</source>
        <translation type="unfinished">Congratulations!</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="489"/>
        <source>You won in %1! What name should this score be saved under?</source>
        <translation type="unfinished">You won in %1! What name should this score be saved under?</translation>
    </message>
</context>
<context>
    <name>ScoreManager</name>
    <message>
        <location filename="scoremanager.cpp" line="24"/>
        <source>Error</source>
        <oldsource>Erreur</oldsource>
        <translation type="unfinished">Error</translation>
    </message>
    <message>
        <location filename="scoremanager.cpp" line="24"/>
        <source>Unable to open the score file.</source>
        <translation type="unfinished">Unable to open the score file.</translation>
    </message>
    <message>
        <location filename="scoremanager.cpp" line="33"/>
        <source>No scores recorded for the level.</source>
        <oldsource>No scores recorded for the %1 level.</oldsource>
        <translation type="unfinished">No scores recorded for the level.</translation>
    </message>
    <message>
        <location filename="scoremanager.cpp" line="53"/>
        <source>%1 min %2 sec</source>
        <translation type="unfinished">%1 min %2 sec</translation>
    </message>
    <message>
        <location filename="scoremanager.cpp" line="54"/>
        <source>%1 sec</source>
        <translation type="unfinished">%1 sec</translation>
    </message>
    <message>
        <location filename="scoremanager.cpp" line="57"/>
        <source>%1 by %2
</source>
        <oldsource>%1 par %2
</oldsource>
        <translation type="unfinished">%1 by %2
</translation>
    </message>
</context>
</TS>
