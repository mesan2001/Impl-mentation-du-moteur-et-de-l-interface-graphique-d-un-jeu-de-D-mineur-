#ifndef DEMINEWIDGET_H
#define DEMINEWIDGET_H

#include <QWidget>
#include <QMenuBar>
#include <QAction>
#include <QMessageBox>
#include <QInputDialog>
#include <QVBoxLayout>
#include <QGridLayout>
#include <QPushButton>
#include <QKeyEvent>
#include <QMainWindow>
#include <QLabel>
#include <QTimer>
#include <QLCDNumber>
#include <QDialog>
#include <QRadioButton>
#include <QDialogButtonBox>
#include <QPainter>

#include "game.h"
#include "scoremanager.h"

class DemineWidget : public QMainWindow {
    Q_OBJECT
public:
    DemineWidget(QWidget *parent = nullptr);
    ~DemineWidget() = default;

private slots:
    void newGame();
    void quitApp();
    void showEasyScores();
    void showMediumScores();
    void showHardScores();
    void updateTimer();
    void updateBombCount();
    void updateSmiley(bool won = false, bool lost = false);
    void showAboutQt() ;
    void showAboutGame() ;
    bool eventFilter(QObject *obj, QEvent *event) ;
    void revealMines(int clickedIndex);
    QPixmap drawMine(bool isClickedMine) ;

private:
    void createActions();
    void createMenus();
    int showLevelSelectionDialog();
    void handleButtonClick(int index, Qt::MouseButton buttonType);
    void initialiseIcone() ;
    void defaite() ;
    void disableAllButtons() ;
    void checkVictory() ;
    void showScoresForDifficulty(const QString& difficulty) ;
    void showScores() ;
    QMenu *fileMenu, *scoresMenu, *helpMenu;
    QAction *newGameAction, *quitAction, *viewScoresActionMedium , *viewScoresActionEasy , *viewScoresActionHard, *aboutQtAction, *aboutGameAction;
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QLCDNumber *timerLCD, *bombCountLCD;
    QLabel *smileyLabel;
    QTimer *timer;
    Game *game;
    ScoreManager *scoreManager;
    bool estcliquable ; // verifie si un bouton peut encore etre cliqué

};

#endif // DEMINEWIDGET_H
