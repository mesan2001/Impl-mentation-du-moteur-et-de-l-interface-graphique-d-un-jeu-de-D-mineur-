<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
<context>
    <name>DemineWidget</name>
    <message>
        <location filename="deminwidget.cpp" line="83"/>
        <source>Quit</source>
        <oldsource>Quitter</oldsource>
        <translation type="unfinished">Quitter</translation>
    </message>
    <message>
        <source>View scores</source>
        <oldsource>Voir les scores</oldsource>
        <translation type="obsolete">Voir les scores</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="122"/>
        <source>Minesweeper game
Developed by Messan Joseph ANANI</source>
        <oldsource>Jeu de démineur
Développé par Messan Joseph ANANI</oldsource>
        <translation type="unfinished">Jeu de démineur.Développé par Messan Joseph ANANI</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="136"/>
        <source>Scores</source>
        <translation type="unfinished">Scores</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="308"/>
        <source>Choose the level</source>
        <oldsource>Choisir le niveau</oldsource>
        <translation type="unfinished">Choisir le niveau</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="18"/>
        <source>Minesweeper</source>
        <translation type="unfinished">Démineur</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="78"/>
        <source>Create a new game</source>
        <translation type="unfinished">Créer une nouvelle partie</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="88"/>
        <source>Leaderboard - Easy</source>
        <translation type="unfinished">Palmarès - Facile</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="90"/>
        <source>Ctrl+E</source>
        <translation type="unfinished">Ctrl+E</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="93"/>
        <source>Leaderboard - Medium</source>
        <translation type="unfinished">Palmarès - Moyen</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="95"/>
        <source>Ctrl+M</source>
        <translation type="unfinished">Ctrl+M</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="98"/>
        <source>Leaderboard - Hard</source>
        <translation type="unfinished">Palmarès - Difficile</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="100"/>
        <source>Ctrl+H</source>
        <translation type="unfinished">Ctrl+H</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="103"/>
        <source>About Qt</source>
        <translation type="unfinished">À propos de Qt</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="105"/>
        <source>Ctrl+A</source>
        <translation type="unfinished">Ctrl+A</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="108"/>
        <location filename="deminwidget.cpp" line="121"/>
        <source>About Minesweeper</source>
        <translation type="unfinished">À propos de Démineur</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="110"/>
        <source>Ctrl+G</source>
        <translation type="unfinished">Ctrl+G</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="131"/>
        <source>File</source>
        <translation type="unfinished">Fichier</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="142"/>
        <source>About</source>
        <translation type="unfinished">À propos</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="311"/>
        <source>Easy - 10x10 with 10 bombs</source>
        <translation type="unfinished">Facile - 10x10 avec 10 bombes</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="312"/>
        <source>Medium - 16x16 with 16 bombs</source>
        <translation type="unfinished">Moyen - 16x16 avec 16 bombes</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="313"/>
        <source>Hard - 32x16 with 64 bombs</source>
        <translation type="unfinished">Difficile - 32x16 avec 64 bombes</translation>
    </message>
    <message>
        <source>Easykk</source>
        <oldsource>Easy</oldsource>
        <translation type="obsolete">Facile</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="372"/>
        <location filename="deminwidget.cpp" line="508"/>
        <source>Medium</source>
        <translation type="unfinished">Moyen</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="377"/>
        <location filename="deminwidget.cpp" line="510"/>
        <source>Hard</source>
        <translation type="unfinished">Difficile</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="360"/>
        <source>Leaderboard %1

</source>
        <oldsource>Palmarès %1

</oldsource>
        <translation type="unfinished">Palmarès %1

</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="323"/>
        <source>OK</source>
        <translation type="unfinished">OK</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="324"/>
        <source>Cancel</source>
        <translation type="unfinished">Annuler</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="367"/>
        <location filename="deminwidget.cpp" line="506"/>
        <source>Easy</source>
        <translation type="unfinished">Facile</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="457"/>
        <source>Game Over</source>
        <translation type="unfinished">Le jeu est terminé</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="457"/>
        <source>Too bad! You triggered a bomb.
Game Over!</source>
        <translation type="unfinished">Dommage ! Vous avez déclenché une bombe
Le jeu est terminé!</translation>
    </message>
    <message>
        <source>Dommage ! Vous avez déclenché une bombe.
Game Over !</source>
        <translation type="obsolete">Dommage ! Vous avez déclenché une bombe</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="483"/>
        <source>%1 min %2 sec</source>
        <translation type="unfinished">%1 min %2 sec</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="484"/>
        <source>%1 sec</source>
        <translation type="unfinished">%1 sec</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="488"/>
        <source>Congratulations!</source>
        <translation type="unfinished">Félicitations!</translation>
    </message>
    <message>
        <location filename="deminwidget.cpp" line="489"/>
        <source>You won in %1! What name should this score be saved under?</source>
        <translation type="unfinished">Vous avez gagné en %1 ! À quel nom ce score doit-il être enregistré ?</translation>
    </message>
</context>
<context>
    <name>ScoreManager</name>
    <message>
        <location filename="scoremanager.cpp" line="24"/>
        <source>Error</source>
        <oldsource>Erreur</oldsource>
        <translation type="unfinished">Erreur</translation>
    </message>
    <message>
        <location filename="scoremanager.cpp" line="24"/>
        <source>Unable to open the score file.</source>
        <translation type="unfinished">Impossible d&apos;ouvrir le fichier de scores.</translation>
    </message>
    <message>
        <location filename="scoremanager.cpp" line="33"/>
        <source>No scores recorded for the level.</source>
        <oldsource>No scores recorded for the %1 level.</oldsource>
        <translation type="unfinished">Aucun score enregistré pour le niveau.</translation>
    </message>
    <message>
        <location filename="scoremanager.cpp" line="53"/>
        <source>%1 min %2 sec</source>
        <translation type="unfinished">%1 min %2 sec</translation>
    </message>
    <message>
        <location filename="scoremanager.cpp" line="54"/>
        <source>%1 sec</source>
        <translation type="unfinished">%1 sec</translation>
    </message>
    <message>
        <location filename="scoremanager.cpp" line="57"/>
        <source>%1 by %2
</source>
        <oldsource>%1 par %2
</oldsource>
        <translation type="unfinished">%1 par %2
</translation>
    </message>
</context>
</TS>
