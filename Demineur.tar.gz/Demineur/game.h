#ifndef GAME_H
#define GAME_H

#include <vector>
#include <QPushButton>
#include <QSet>
#include <random>

class Game {
public:
    Game(int gridWidth, int gridHeight, int bombCount);
    ~Game() = default;

    void initialize();
    void placeBombs();

    bool isBomb(int index) const;
    int countAdjacentBombs(int index) const;
    QVector<int> getAdjacentIndices(int index) const;
    void revealAdjacentEmptyCells(int index, QSet<int>& visited);
    bool checkVictory() const;
    void moveBomb(int index);
    std::vector<QPushButton*>& getButtons();
    const std::vector<bool>& getBombLocations() const;
    int getRemainingBombs() const;
    void setRemainingBombs(int bombs);
    bool isFirstClick() const { return firstClick; }
    void setFirstClick(bool value) { firstClick = value; }
    void setElapsedTime( int e) {elapsedTime = e; } ;
    int getElapsedTime(){return elapsedTime ;}
    void setBombCount(int i){bombCount = i ;};
    int getBombCount(){return bombCount ;};
    QString getDifficulty(){return difficulty ;};
    void setDifficulty(QString d){difficulty = d ; } ;

private:
    int gridWidth, gridHeight, bombCount;
    bool firstClick;
    std::vector<QPushButton*> buttons;
    std::vector<bool> bombLocations;
    void clearGrid();
    int elapsedTime ;
    QString difficulty ;

};

#endif // GAME_H
