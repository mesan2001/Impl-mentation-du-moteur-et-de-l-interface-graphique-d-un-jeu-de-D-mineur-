#include "scoremanager.h"
#include <QCoreApplication>

ScoreManager::ScoreManager(const QString& difficulty) : difficulty(difficulty) {}

// cette fonction retoune le chemin du fichier de scores pour la difficulté actuelle
QString ScoreManager::getScoreFilePath() const {
    // creation du dossier de scores s'il n'existe pas
    QString directoryPath = QCoreApplication::applicationDirPath() + "/scores";
    QDir().mkpath(directoryPath);
    return directoryPath + QString("/scores_%1.txt").arg(difficulty);
}

void ScoreManager::saveScore(const QString& playerName, int time) {
    QString filePath = getScoreFilePath();

    // Ouvrir le fichier pour ajouter le score
    QFile file(filePath);
    if (file.open(QIODevice::Append | QIODevice::Text)) {
        QTextStream out(&file);
        out << time << " " << playerName << "\n"; // Sauvegarde du temps et le nom
        file.close();
    } else {
        QMessageBox::critical(nullptr, tr("Error"), tr("Unable to open the score file."));
    }
}

QString ScoreManager::getScores() const {
    QString filePath = getScoreFilePath();
    QFile file(filePath);

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return QString(tr("No scores recorded for the level.")) ;
    }

    // Read the scores
    QString scoreText = "";
    QTextStream in(&file);

    while (!in.atEnd()) {
        // ici je split la ligne , je prends la premiere colonne et tout le reste c'est le nom du joueur
        QString line = in.readLine();
        QStringList parts = line.split(" "); //

        if (parts.size() >= 2) {
            int time = parts[0].toInt();
            QString playerName = parts.mid(1).join(" ");

            int minutes = time / 60;
            int seconds = time % 60;

            QString timeStr = (minutes > 0)
                ? tr("%1 min %2 sec").arg(minutes).arg(seconds)
                : tr("%1 sec").arg(seconds);

            // ajout de la ligne
            scoreText += tr("%1 by %2\n").arg(timeStr).arg(playerName);
        }
    }

    file.close();
    return scoreText;
}
