#ifndef SCOREMANAGER_H
#define SCOREMANAGER_H

#include <QString>
#include <QFile>
#include <QTextStream>
#include <QDir>
#include <QMessageBox>
#include <QObject>  // Ajouté pour QObject

class ScoreManager : public QObject  // Héritage de QObject
{
    Q_OBJECT  // Ajouté pour permettre l'utilisation de tr()

public:
    ScoreManager(const QString& difficulty);
    ~ScoreManager() = default;

    void saveScore(const QString& playerName, int time);
    QString getScores() const;
    void setDifficulty(QString d){difficulty = d;}
    QString getDifficulty(){return difficulty;}

private:
    QString difficulty;
    QString getScoreFilePath() const;
};

#endif // SCOREMANAGER_H
