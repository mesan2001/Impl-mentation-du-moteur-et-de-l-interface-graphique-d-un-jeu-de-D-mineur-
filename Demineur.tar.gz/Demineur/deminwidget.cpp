#include "deminwidget.h"
#include <QApplication>

DemineWidget::DemineWidget(QWidget *parent)
    : QMainWindow(parent), timer(new QTimer(this)) {

// Architecture de mon interface:
    //  |Drapeau      "Démineur"|
    //  |Fichier   Score   Aide |
    //  -----------------------
    //  |  Timer  Smiley  Bomb |
    //  -----------------------
    //  |       Grille du jeu  |
    //  |      (Cases ici)     |
    //   -----------------------


    setWindowTitle(tr("Minesweeper"));
    initialiseIcone();

    // Initialisation des objets
    createActions();
    createMenus();

    // l'affichage du timer, du compteur de bombes et du smiley
    timerLCD = new QLCDNumber(3, this);
    bombCountLCD = new QLCDNumber(3, this);
    smileyLabel = new QLabel(this);
    smileyLabel->setPixmap(QPixmap(":/images/neutre.png").scaled(30, 30)); // de base neutre


    // Configuration des QLCDNumber
    timerLCD->setSegmentStyle(QLCDNumber::Filled); // style de segment de Mr Legay
    bombCountLCD->setSegmentStyle(QLCDNumber::Filled);

    // Configuration de l'affichage initial
    timerLCD->display("000"); // "000" par defaut
    bombCountLCD->display("000");

    // Layout pour les éléments supérieurs

    QHBoxLayout *topLayout = new QHBoxLayout();
    topLayout->addWidget(timerLCD);
    topLayout->addStretch();
    topLayout->addWidget(smileyLabel);
    topLayout->addStretch();
    topLayout->addWidget(bombCountLCD);

    // Création du layout principal
    centralWidget = new QWidget(this);
    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);
    mainLayout->addLayout(topLayout);
    gridLayout = new QGridLayout();
    mainLayout->addLayout(gridLayout);

    setCentralWidget(centralWidget);
    setStyleSheet("QWidget { color: black; }") ; // je veux que les ecritures apparaissent en fond noir

    // de base le jeu est initialisé à  0 0 0
    // pas de niveau de difficulté à proprement de base
    game = new Game(0, 0, 0);
    game->setDifficulty(QString("")) ;
    scoreManager = new ScoreManager(QString(""));
    // Connexion du timer
    connect(timer, &QTimer::timeout, this, &DemineWidget::updateTimer);
    resize(165, 80);  // Redimensionnement de la fenêtre à 165 X 80
}
void DemineWidget::initialiseIcone()
{
    // Définir l'icône de la fenêtre
    QPixmap pixmap(":/images/drapeau.png");
    setWindowIcon(QIcon(pixmap));
}

void DemineWidget::createActions()
{
    // Action "Nouvelle partie"
    newGameAction = new QAction(tr("Create a new game"), this);
    connect(newGameAction, &QAction::triggered, this, &DemineWidget::newGame);
    newGameAction->setShortcut(QKeySequence::New);

    // Action "Quitter"
    quitAction = new QAction(tr("Quit"), this);
    connect(quitAction, &QAction::triggered, this, &DemineWidget::quitApp);
    quitAction->setShortcut(QKeySequence::Quit);

    // Action pour voir les scores du niveau Facile
    viewScoresActionEasy = new QAction(tr("Leaderboard - Easy"), this);
    connect(viewScoresActionEasy, &QAction::triggered, this, &DemineWidget::showEasyScores);
    viewScoresActionEasy->setShortcut(tr("Ctrl+E"));

    // Action pour voir les scores du niveau Moyen
    viewScoresActionMedium = new QAction(tr("Leaderboard - Medium"), this);
    connect(viewScoresActionMedium, &QAction::triggered, this, &DemineWidget::showMediumScores);
    viewScoresActionMedium->setShortcut(tr("Ctrl+M"));

    // Action pour voir les scores du niveau Difficile
    viewScoresActionHard = new QAction(tr("Leaderboard - Hard"), this);
    connect(viewScoresActionHard, &QAction::triggered, this, &DemineWidget::showHardScores);
    viewScoresActionHard->setShortcut(tr("Ctrl+H"));

    // Action "About Qt"
    aboutQtAction = new QAction(tr("About Qt"), this);
    connect(aboutQtAction, &QAction::triggered, this, &DemineWidget::showAboutQt);
    aboutQtAction->setShortcut(tr("Ctrl+A"));

    // Action "About Minesweeper"
    aboutGameAction = new QAction(tr("About Minesweeper"), this);
    connect(aboutGameAction, &QAction::triggered, this, &DemineWidget::showAboutGame);
    aboutGameAction->setShortcut(tr("Ctrl+G"));
}

void DemineWidget::showAboutQt()
{
    // infos sur Qt
    QApplication::aboutQt();
}
void DemineWidget::showAboutGame()
{
    // Afficher les informations sur le jeu
    QMessageBox::about(this, tr("About Minesweeper"),
                       tr("Minesweeper game\nDeveloped by Messan Joseph ANANI"));

}

void DemineWidget::createMenus()
{
    //AJOUT DES MENUS AUX menuBar

    // Menu "Fichier"
    fileMenu = menuBar()->addMenu(tr("File"));
    fileMenu->addAction(newGameAction); // ajout des actions sur les menus
    fileMenu->addAction(quitAction);

    // Menu "Scores"
    scoresMenu = menuBar()->addMenu(tr("Scores"));
    scoresMenu->addAction(viewScoresActionEasy);
    scoresMenu->addAction(viewScoresActionMedium);
    scoresMenu->addAction(viewScoresActionHard);

    // Menu "Aide"
    helpMenu = menuBar()->addMenu(tr("About"));
    helpMenu->addAction(aboutQtAction);
    helpMenu->addAction(aboutGameAction);
}

void DemineWidget::newGame() {
    int level = showLevelSelectionDialog();
    if (level == -1) return;

    // Définition des paramètres selon le niveau
    QString difficulty;
    int width, height, bombs;

    switch (level) {
        case 0: // Easy
            width = 10; height = 10; bombs = 10; difficulty = "Easy";
            break;
        case 1: // Medium
            width = 16; height = 16; bombs = 16; difficulty = "Medium";
            break;
        case 2: // Hard
            width = 32; height = 16; bombs = 64; difficulty = "Hard";
            break;
        default:
            return;
    }


    // Réinitialisation du jeu
    delete game ;
    delete scoreManager ;
    game = new Game(width, height, bombs);
    game->setElapsedTime(0);
    game->setDifficulty(QString(difficulty)) ;
    scoreManager = new ScoreManager(difficulty);

    updateTimer(); // timer à 000 au lancement et fera le decomptage à partir de start(en dessous)
    updateSmiley(); // smiley à neutre au lancement
    updateBombCount(); // qui compte le nombe de compte
    timer->start(1000);
    estcliquable = true ; // les boutons sont cliquables dorénavant( je m'en sert apres pour la deconnexion)

    // Suppression de la grille actuelle
    QLayoutItem *item;
    while ((item = gridLayout->takeAt(0)) != nullptr) {
        delete item->widget();
        delete item;
    }

    gridLayout->setSpacing(0);
    gridLayout->setContentsMargins(0, 0, 0, 0);

    // Création et ajout des nouveaux boutons
    for (int i = 0; i < height; ++i) {
        for (int j = 0; j < width; ++j) {
            int index = i * width + j;
            game->getButtons()[index] = new QPushButton(this);
            QPushButton *button = game->getButtons()[index];

            button->setFixedSize(30, 30);
            button->setStyleSheet("border: 1px solid black;");

            connect(button, &QPushButton::clicked, this, [this, index]() {
                handleButtonClick(index, Qt::LeftButton); // Cette lambda fonction appelle handleButtonClick
                                                          // pour le bouton correspondant à l'index donné.
                                                          // Elle agit comme un signal connecté au clic du bouton.
            });

            button->installEventFilter(this);
            gridLayout->addWidget(button, i, j); // ajout du bouton à la grille
        }
    }

    adjustSize();
    setFixedSize(width * 30 + 20, height * 30 + 80); // j'interdie ici le redimensionnemant de la fenetre
                                                        // en donnant une taille precise pour la fenetre
                                                        // en fonction du niveau du jeu
}

void DemineWidget::handleButtonClick(int index, Qt::MouseButton buttonType) {
    QPushButton *button = game->getButtons()[index];


    if (!button || !button->isEnabled()) {
        return; // Vérifier que le bouton existe et est cliquable
    }

    // Clic droit qui gère les drapeaux et les poteaux.
    // À chaque clic droit, je modifie la propriété "iconState" du bouton concerné.
    // Cette propriété permet de suivre l'état du bouton et d'alterner entre trois états :
    // 1. Vide → Ajout d'un drapeau si des bombes restent à placer.
    // 2. Drapeau → Remplacement par un poteau (indicateur neutre).
    // 3. Poteau → Suppression de l'icône pour revenir à l'état initial.
    if (buttonType == Qt::RightButton) {
        // Vérifier l'état actuel
        QString state = button->property("iconState").toString();

        if (state.isEmpty()) {
            // Cas 1 : Placer un drapeau
            if (game->getRemainingBombs() > 0) {
                button->setIcon(QIcon(":/images/drapeau.png"));
                button->setProperty("iconState", "flag");
                game->setRemainingBombs(game->getRemainingBombs() - 1);
            }
        }
        else if (state == "flag") {
            // Cas 2 : Remplacer par un poteau
            button->setIcon(QIcon(":/images/poteau.png"));
            button->setProperty("iconState", "pole");
            game->setRemainingBombs(game->getRemainingBombs() + 1);
        }
        else if (state == "pole") {
            // Cas 3 : Retirer l'icône
            button->setIcon(QIcon());
            button->setProperty("iconState", "");
        }

        updateBombCount();
    }
    else if (buttonType == Qt::LeftButton) {

        // Clic gauche qui permet de révéler une case.
        // Si c'est le premier clic de la partie, je m'assure qu'il ne tombe pas sur une bombe.

        if (game->isFirstClick()) {
            game->setFirstClick(false);

            if (game->isBomb(index)) {
                game->moveBomb(index);
            }
        }

        // Vérifier si la case est vide (pas de drapeau ni de poteau)
        QString state = button->property("iconState").toString();
        if (state.isEmpty()) {
            // Vérifier si la case contient une bombe
            if (game->isBomb(index)) {
                revealMines(index);
                disableAllButtons();
                defaite();
            } else {
                // Révéler la case
                int bombCount = game->countAdjacentBombs(index);
                button->setStyleSheet("border: 1px solid lightgreen;");

                if (bombCount > 0) {
                    button->setText(QString::number(bombCount));
                } else {
                    QSet<int> visited;
                    game->revealAdjacentEmptyCells(index, visited);
                }

                button->setEnabled(false); // Désactiver la case après révélation
                checkVictory(); // Vérifier la victoire après chaque révélation
            }
        }
        // Si la case contient un drapeau ou un poteau, ne rien faire
    }
}



int DemineWidget::showLevelSelectionDialog()
{
    //cette fonction recupere le niveau de difficulté choisi par l'utilisateur
    QDialog dialog(this);
    dialog.setWindowTitle(tr("Choose the level"));

    QVBoxLayout layout(&dialog);
    QRadioButton *easyButton = new QRadioButton(tr("Easy - 10x10 with 10 bombs"), &dialog);
    QRadioButton *mediumButton = new QRadioButton(tr("Medium - 16x16 with 16 bombs"), &dialog);
    QRadioButton *hardButton = new QRadioButton(tr("Hard - 32x16 with 64 bombs"), &dialog);

    easyButton->setChecked(true); // Par défaut, "Facile" est sélectionné

    layout.addWidget(easyButton);
    layout.addWidget(mediumButton);
    layout.addWidget(hardButton);

    // Création de la boîte de boutons avec les libellés personnalisés
    QDialogButtonBox buttonBox(&dialog);
    QPushButton *okButton = buttonBox.addButton(tr("OK"), QDialogButtonBox::AcceptRole);
    QPushButton *cancelButton = buttonBox.addButton(tr("Cancel"), QDialogButtonBox::RejectRole);

    layout.addWidget(&buttonBox);

    connect(okButton, &QPushButton::clicked, &dialog, &QDialog::accept);
    connect(cancelButton, &QPushButton::clicked, &dialog, &QDialog::reject);

    if (dialog.exec() == QDialog::Accepted) {
        if (mediumButton->isChecked()) return 1;
        if (hardButton->isChecked()) return 2;
        return 0; // Facile par défaut
    }

    return -1; // Annulation
}



void DemineWidget::updateTimer() {
    int elapsedTime = game->getElapsedTime()+1 ;
    // Incrémenter le temps écoulé
    game->setElapsedTime(elapsedTime);
    // Formatage du temps avec des zéros en début pour toujours avoir trois chiffres
    QString timeStr = QString::number(elapsedTime).rightJustified(3, '0'); // Ajoute des zéros à gauche si nécessaire
    timerLCD->display(timeStr); // Affiche le temps formaté
}

void DemineWidget::updateBombCount() {
    QString  bombStr = QString::number(game->getRemainingBombs()).rightJustified(3, '0');
    bombCountLCD->display(bombStr);
}


// fonctin qui affiche des scores en fonction du niveau de difficulté
void DemineWidget::showScoresForDifficulty(const QString& difficulty) {

    QString text = tr("Leaderboard %1\n\n").arg(difficulty);
    QMessageBox::information(this, text, scoreManager->getScores());
}

//slot faisant juste appel à la fonction showScoresForDifficulty en parametre le niveau de difficulté
void DemineWidget::showEasyScores() {
    scoreManager ->setDifficulty(QString("Easy"));
    showScoresForDifficulty(tr("Easy"));
}

void DemineWidget::showMediumScores() {
    scoreManager ->setDifficulty(QString("Medium"));
    showScoresForDifficulty(tr("Medium"));
}

void DemineWidget::showHardScores() {
    scoreManager ->setDifficulty(QString("Hard"));
    showScoresForDifficulty(tr("Hard"));
}

void DemineWidget::quitApp() {
    QApplication::quit();
}


void DemineWidget::updateSmiley(bool won, bool lost) {
    if (won) {
        smileyLabel->setPixmap(QPixmap(":/images/content.png").scaled(30, 30));
    } else if (lost) {
        smileyLabel->setPixmap(QPixmap(":/images/triste.png").scaled(30, 30));
    } else {
        smileyLabel->setPixmap(QPixmap(":/images/neutre.png").scaled(30, 30));
    }
}

bool DemineWidget::eventFilter(QObject *obj, QEvent *event) {
    if (event->type() == QEvent::MouseButtonPress) {
        QMouseEvent *mouseEvent = static_cast<QMouseEvent *>(event);

        if (QPushButton *button = qobject_cast<QPushButton *>(obj)) {
            auto &buttons = game->getButtons(); // Récupération des boutons depuis `Game`
            auto it = std::find(buttons.begin(), buttons.end(), button);

            if (it != buttons.end()&&  estcliquable) {
                int index = std::distance(buttons.begin(), it);
                handleButtonClick(index, mouseEvent->button());
                return true; // Événement traité
            }
        }
    }
    return QObject::eventFilter(obj, event);
}

void DemineWidget::revealMines(int clickedIndex) {
    for (int i = 0; i < game->getBombLocations().size(); ++i) {
        QPushButton *button = game->getButtons()[i];
        QString state = button->property("iconState").toString();
        if (game->getBombLocations()[i]) {
            if (state != "flag") {
                button->setIcon(QIcon(drawMine(i == clickedIndex)));
                button->setIconSize(QSize(20, 20));  // Ajustez la taille si nécessaire
            }
            button->setStyleSheet("border: 1px solid red;");
        } else {
            if (state == "flag") {
                button->setStyleSheet("background-color: yellow;");
            }
        }
    }
}

QPixmap DemineWidget::drawMine(bool isClickedMine) {
    int size = 20;  // Taille totale du QPixmap
    QPixmap pixmap(size, size);
    pixmap.fill(Qt::transparent);

    QPainter painter(&pixmap);
    painter.setRenderHint(QPainter::Antialiasing);
    QColor mineColor = isClickedMine ? Qt::red : Qt::black;

    painter.setPen(QPen(mineColor, 1));
    painter.setBrush(mineColor);
    // Dessiner le cercle au centre du QPixmap (réduit pour s'adapter)
    painter.drawEllipse(3, 3, 14, 14);

    // Dessiner les 4 traits (adaptés à la nouvelle taille)
    painter.drawLine(10, 2, 10, 18); // Vertical
    painter.drawLine(2, 10, 18, 10); // Horizontal
    painter.drawLine(2, 2, 18, 18);  // Diagonale 1
    painter.drawLine(2, 18, 18, 2);  // Diagonale 2

    return pixmap;
}


void DemineWidget::defaite()
{
    QMessageBox::critical(this, tr("Game Over"), tr("Too bad! You triggered a bomb.\nGame Over!"));    timer->stop();
    updateSmiley(false, true);

}
void DemineWidget::disableAllButtons() {
    for (QPushButton* button : game->getButtons()) {
        button->disconnect(); // je deconnecte tous les signaux
    }
    estcliquable = false; // Mise à jour l'état de cliquabilité
}

void DemineWidget::checkVictory() { // fait appel à la fonction checkVictory de la classe game
    if (!game->checkVictory()) {
        return; // Encore des cases à découvrir
    }

    // une  Victoire
    timer->stop();
    disableAllButtons();
    updateSmiley(true, false);

    // Calcul du temps de jeu
    int elapsedTime = game->getElapsedTime();
    int minutes = elapsedTime / 60;
    int seconds = elapsedTime % 60;
    QString timeStr = (minutes > 0)
        ? QString(tr("%1 min %2 sec")).arg(minutes).arg(seconds)
        : QString(tr("%1 sec")).arg(seconds);

    //   le nom du joueur
    bool ok;
    QString playerName = QInputDialog::getText(this, tr("Congratulations!"),
        tr("You won in %1! What name should this score be saved under?").arg(timeStr),
        QLineEdit::Normal, "", &ok);

    // Sauvegarde dans le fichier spécifique au niveau
    if (ok && !playerName.isEmpty()) {
        ScoreManager scoreManager(game->getDifficulty()); // Instancier ScoreManager avec la difficulté
        scoreManager.saveScore(playerName, elapsedTime);
    }

    //  Affichage du palmarès à chaque fois que le joueur gagne
    showScores();
}

void DemineWidget::showScores() {
    // Ici je traduis la difficulté en tr pour faciliter la tradcution
    QString difficultyText;
    if (game->getDifficulty() == "Easy") {
        difficultyText = tr("Easy");
    } else if (game->getDifficulty() == "Medium") {
        difficultyText = tr("Medium");
    } else if (game->getDifficulty() == "Hard") {
        difficultyText = tr("Hard");
    }
    showScoresForDifficulty(difficultyText) ; ;

}
